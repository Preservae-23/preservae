import * as React from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useState, useEffect } from 'react';
import {
  Text,
  StyleSheet,
  View,
  TouchableOpacity,
  Image,
  ScrollView,
} from 'react-native';
import { DADOS } from '../App';

export default class Welcome extends React.Component {
  constructor(props) {
    super(props);

    if (this.props.route.params == null) {
      this.state = {
        usuarios: null,
        userId: null,
        user: null
      };
      this.testEffect();
    } else {
      
      this.testEffect();
    }
  };
  
  testEffect = async () => {
    try {
      const value = await AsyncStorage.getItem('userId');
      if(value !== null) {
        this.setId(value);
        this.getData(value);
      } else {
        alert("Vaszio");
        console.log("Error");
      }
    } catch (error) {
      console.log("Error: " + error);
    }
}

  setUsers = (response) => {
    this.setState({
      usuarios: response,
    });
  }

  setUser = (response) => {
    this.setState({
      user: response,
    });
  }

  setId = (response) => {
    this.setState({
      userId: response,
    });
  }

  getData = async (id) => {
    fetch("https://65304e5c6c756603295e875c.mockapi.io/cadastro")
    .then(response => response.json())
    .then(json => {
      this.setUsers(json);
      json.forEach(user => {
        if(user.id == id) {
          console.log("Usuário: " + JSON.stringify(user));
          this.setUser(user);
        }
      });
      // console.log("Usuário: " + JSON.stringify(user));
      // this.setUser(JSON.stringify(user));
    })
    .catch(error => {
      console.log("Get data error: " + error)
      alert(error);
      this.getData()
  }, [])
  }

  buttonEditar = () => {
    this.props.navigation.push('EditarUser');
  };

  render() {
    return (
      <View style={styles.container}>
        <Image style={styles.onda} source={require('../assets/onda.png')} />
        <Text style={styles.titulo}> { this.state.user != null ? this.state.user.nome : "Nome..." } </Text>

        <Image
          style={styles.usuario}
          source={this.state.user != null ? { uri: this.state.user.fotousuario } : require('../assets/IconPerfil.png')}
        />

        <TouchableOpacity style={styles.botao} onPress={this.buttonEditar}>
          <View>
            <Text style={styles.corTexto}> Editar Perfil </Text>
          </View>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#FFF',
    height: '100%',
  },

  onda: {
    height: 500,
    marginLeft: -60,
  },

  titulo: {
    marginTop: -440,
    marginBottom: 100,
    fontSize: 50,
    fontFamily: 'Avenir',
    textAlign: 'center',
    color: 'white',
    fontWeight: 'bold',
  },

  usuario: {
    marginLeft: 120,
    height: 200,
    width: 150,
  },

  botao: {
    alignItems: 'center',
    backgroundColor: '#30615D',
    padding: 10,
    marginLeft: 70,
    marginRight: 70,
    marginTop: 100,
    borderRadius: 60,
  },

  corTexto: {
    color: 'white',
    fontSize: 20,
    fontFamily: 'Avenir',
  },
});
