class Globais {
  static ponto = 0;
  static total = 0;
  static telefone = 0;
}

export default Globais;
